#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess, threading, time, random, shutil

class App:
    def __init__(self, root):
        self.root=root
        root.title("Cursor Purupuru 0.1 🖱️〰️")
        root.geometry("430x310")
        self.running=False
        self.worker=None

        ttk.Label(root,text="Cursor Purupuru",font=("Sans",20,"bold")).pack(pady=(15,3))
        ttk.Label(root,text="Waylandで本物のカーソルをプルプル").pack()

        f=ttk.Frame(root); f.pack(fill="x",padx=24,pady=14)
        ttk.Label(f,text="震え幅 (px)").grid(row=0,column=0,sticky="w")
        self.amp=tk.IntVar(value=3)
        ttk.Scale(f,from_=1,to=15,variable=self.amp,orient="horizontal").grid(row=0,column=1,sticky="ew")
        self.amp_label=ttk.Label(f,text="3"); self.amp_label.grid(row=0,column=2)
        self.amp.trace_add("write",lambda *_:self.amp_label.config(text=str(self.amp.get())))

        ttk.Label(f,text="速さ").grid(row=1,column=0,sticky="w",pady=12)
        self.speed=tk.IntVar(value=12)
        ttk.Scale(f,from_=2,to=30,variable=self.speed,orient="horizontal").grid(row=1,column=1,sticky="ew")
        self.speed_label=ttk.Label(f,text="12"); self.speed_label.grid(row=1,column=2)
        self.speed.trace_add("write",lambda *_:self.speed_label.config(text=str(self.speed.get())))
        f.columnconfigure(1,weight=1)

        self.btn=ttk.Button(root,text="▶ プルプル開始",command=self.toggle)
        self.btn.pack(ipadx=20,ipady=8)
        ttk.Button(root,text="■ 緊急停止",command=self.stop).pack(pady=8)
        self.status=ttk.Label(root,text="停止中")
        self.status.pack()

        root.protocol("WM_DELETE_WINDOW",self.close)

    def command(self,dx,dy):
        # ydotool uses a real uinput-backed virtual mouse.
        subprocess.run(["ydotool","mousemove","--",str(dx),str(dy)],
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

    def loop(self):
        # Move away and then back, so the pointer does not drift across the desktop.
        while self.running:
            a=max(1,int(self.amp.get()))
            dx=random.randint(-a,a); dy=random.randint(-a,a)
            if dx==0 and dy==0: dx=1
            self.command(dx,dy)
            time.sleep(1/max(2,int(self.speed.get())))
            if not self.running: break
            self.command(-dx,-dy)
            time.sleep(1/max(2,int(self.speed.get())))

    def toggle(self):
        if self.running: self.stop()
        else: self.start()

    def start(self):
        if not shutil.which("ydotool"):
            messagebox.showerror("ydotool がありません",
              "先に ydotool をインストールしてください:\n\nsudo apt install ydotool")
            return
        self.running=True
        self.btn.config(text="⏸ プルプル停止")
        self.status.config(text="🖱️〰️ プルプル中")
        self.worker=threading.Thread(target=self.loop,daemon=True)
        self.worker.start()

    def stop(self):
        self.running=False
        self.btn.config(text="▶ プルプル開始")
        self.status.config(text="停止中")

    def close(self):
        self.stop()
        self.root.after(80,self.root.destroy)

root=tk.Tk()
App(root)
root.mainloop()
